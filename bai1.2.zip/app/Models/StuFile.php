<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StuFile extends Model
{
    use HasFactory;

    protected $table = 'stufiles';
}
