<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <form action="<?php echo e(route('listUserStu')); ?> ", method="GET">
        <?php echo csrf_field(); ?>
        <button>
            Users
        </button>
    </form>

    <form action="<?php echo e(route('messages')); ?> ", method="GET">
        <?php echo csrf_field(); ?>
            <button>
                Messages
            </button>
    </form>
   
   <form action="<?php echo e(route('assignmentStu')); ?> ", method="GET">
       <?php echo csrf_field(); ?>
       <button>
           Assignment
       </button>
   </form>

   <form action="<?php echo e(route('challengesStu')); ?> ", method="GET">
    <?php echo csrf_field(); ?>
    <button>
        Challenges
    </button>
    </form>
   
    <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
   <?php /**PATH F:\XamPP\htdocs\bai1.2\resources\views/student/homeStu.blade.php ENDPATH**/ ?>