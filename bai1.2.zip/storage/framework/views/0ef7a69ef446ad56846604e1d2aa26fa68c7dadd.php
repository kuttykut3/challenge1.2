
    <form action="<?php echo e(route('redirect')); ?> ", method="GET">
        <?php echo csrf_field(); ?>
        <button>
            Back to Home
        </button>
    </form>

    <form action="<?php echo e(route('listUserStu')); ?> ", method="GET">
        <?php echo csrf_field(); ?>
        <button>
            Users
        </button>
    </form>
    
    <form action="<?php echo e(route('messages')); ?> ", method="GET">
        <?php echo csrf_field(); ?>
            <button>
                Messages
            </button>
    </form>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('List Assignments')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
   <table border="1" width="100%">
       <tr>
           <th>Created at</th>
           <th>Description</th>
           <th>#</th>
       </tr>
       <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
               <td><?php echo e($file->created_at); ?></td>
               <td><?php echo e($file->name); ?></td>
               <td> 
                   <form action="<?php echo e(route('detailStu', ['id' => $file->id])); ?> ", method="GET">
                       <?php echo csrf_field(); ?>
                       <button>
                           Detail
                       </button>
                   </form>
   
               </td>
               
           </tr>    
           
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </table>
   <?php echo e($files->links()); ?>

   
   <form action="<?php echo e(route('challengesStu')); ?> ", method="GET">
    <?php echo csrf_field(); ?>
    <button>
        Challenges
    </button>
    </form>
 
   
   <?php /**PATH F:\XamPP\htdocs\bai1.2\resources\views/student/assignment.blade.php ENDPATH**/ ?>