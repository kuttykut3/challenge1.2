
    <form action="<?php echo e(route('redirect')); ?> ", method="GET">
        <?php echo csrf_field(); ?>
        <button>
            Back to Home
        </button>
    </form>

    <form action="<?php echo e(route('add')); ?> ", method="GET">
       <?php echo csrf_field(); ?>
       <button>
           New
       </button>
   </form>
   <table border="1" width="100%">
       <tr>
           <th>Username</th>
           <th>Fullname</th>
           <th>Email</th>
           <th>Phone number</th>
           <th>Role</th>
           <th>#</th>
       </tr>
       <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
               <td><?php echo e($user->username); ?></td>
               <td><?php echo e($user->name); ?></td>
               <td><?php echo e($user->email); ?></td>
               <td><?php echo e($user->phone); ?></td>
               <td><?php echo e(($user->role == '0') ? 'Student' : 'Teacher'); ?></td>
               <td> 
                   
                   <form action="<?php echo e(route('edit', ['id' => $user->id])); ?> ", method="GET">
                       <?php echo csrf_field(); ?>
                       <button>
                           Edit
                       </button>
                   </form>

                   <form action="<?php echo e(route('detailUser', ['id' => $user->id])); ?> ", method="GET">
                    <?php echo csrf_field(); ?>
                    <button>
                        Detail
                    </button>
                </form>
   
                   <form action="<?php echo e(route('destroy', ['id' => $user->id])); ?> ", method="POST">
                       <?php echo csrf_field(); ?>
                       <?php echo method_field('DELETE'); ?>
                       <button>
                           Delete
                       </button>
                   </form>
               </td>
               
           </tr>    
           
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </table>
   <?php echo e($users->links()); ?>

   
   <form action="<?php echo e(route('assignment')); ?> ", method="GET">
       <?php echo csrf_field(); ?>
       <button>
           Assignment
       </button>
   </form>

   <form action="<?php echo e(route('challenges')); ?> ", method="GET">
    <?php echo csrf_field(); ?>
    <button>
        Challenges
    </button>
    </form>
   
   
   <?php /**PATH F:\XamPP\htdocs\bai1.2\resources\views/admin/listuser.blade.php ENDPATH**/ ?>