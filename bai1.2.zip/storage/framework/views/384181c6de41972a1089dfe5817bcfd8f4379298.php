
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Assignments [' . $detailFile->name . ']')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <h3>
        File: 
        <a href="<?php echo e(route('viewFileStu', ['id' => $detailFile->id])); ?>", method="GET"><?php echo e($detailFile->name); ?></a>
    </h3>

    <h3>
        Download File: 
        <a href="<?php echo e(route('downloadFileStu', ['id' => $detailFile->id])); ?>", method="GET"><?php echo e($detailFile->name); ?></a>
        
    </h3>

    <div class="container mt-4">
 
        <h2>Turn in</h2>
       
            <form method="POST" enctype="multipart/form-data" id="upload-file" action="<?php echo e(route('turnIn', ['id' => $detailFile->id])); ?>" >
             <?php echo csrf_field(); ?>          
                <div class="row">
       
                    <div class="col-md-12">
                        <div class="form-group">
                            <input type="file" name="file" placeholder="Choose file" id="file">
                              <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                       
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary" id="submit">Submit</button>
                    </div>
                </div>     
            </form>
      </div>

      <table border="1" width="100%">
        <tr>
            <th>Time submit</th>
            <th>File</th>
            <th>#</th>
        </tr>
        
        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($detailFile->id == $file->assignment_id): ?>
            <tr>
                <td><?php echo e($file->created_at); ?></td>
                <td><a href="<?php echo e(route('viewFileTurnedIn', ['id' => $file->id])); ?>", method="GET"><?php echo e($file->name); ?></a></td>
                <td> 
                
                </td>
               
            </tr>    
            <?php endif; ?>      
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
    </table>

    <form action="<?php echo e(route('assignmentStu')); ?> ", method="GET">
        <?php echo csrf_field(); ?>
        <button>
            Back to Assignments
        </button>
    </form>

<?php /**PATH F:\XamPP\htdocs\bai1.2\resources\views/student/assignmentDetail.blade.php ENDPATH**/ ?>