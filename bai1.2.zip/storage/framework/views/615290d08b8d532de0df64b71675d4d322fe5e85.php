
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Assignments [' . $detailFile->name . ']')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <h3>
        File: 
        <a href="<?php echo e(route('viewFile', ['id' => $detailFile->id])); ?>", method="GET"><?php echo e($detailFile->name); ?></a>
        
    </h3>
    
    <form action="<?php echo e(route('changeFile', ['id' => $detailFile->id])); ?> ", method="GET">
        <?php echo csrf_field(); ?>
        <button>
            Change File
        </button>
    </form>

    
    <table border="1" width="100%">
        <tr>
            <th>Time submit</th>
            <th>File</th>
            <th>Student</th>
        </tr>
        
        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($detailFile->id == $file->assignment_id): ?>
            <tr>
                <td><?php echo e($file->created_at); ?></td>
                <td><a href="<?php echo e(route('viewFileTurnedIn', ['id' => $file->id])); ?>", method="GET"><?php echo e($file->name); ?></a></td>
            
                <td> 
                <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php if($stu->id == $file->owner_id): ?>
                        <?php echo e($stu->name); ?>

                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
               
            </tr>    
            <?php endif; ?>      
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         
    </table>
    <?php echo e($files->links()); ?>

   

    <form action="<?php echo e(route('assignment')); ?> ", method="GET">
        <?php echo csrf_field(); ?>
        <button>
            Back to Assignments
        </button>
    </form>

<?php /**PATH F:\XamPP\htdocs\bai1.2\resources\views/file-detail.blade.php ENDPATH**/ ?>