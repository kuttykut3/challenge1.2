<tr class="<?php echo e($thread->isUnread(Auth::id()) ? 'font-bold' : ''); ?>">
    <td class="px-5 py-5 text-sm bg-white border-b border-gray-200">
        <a class="hover:underline" href="<?php echo e(route('messages.show', $thread)); ?>"><?php echo e($thread->creator()->name); ?></a>
    </td>
    <td class="px-5 py-5 text-sm bg-white border-b border-gray-200">
        <a class="hover:underline" href="<?php echo e(route('messages.show', $thread)); ?>"><?php echo e($thread->subject); ?></a>
    </td>
    <td class="px-5 py-5 text-sm bg-white border-b border-gray-200">
        <form action="<?php echo e(route('messages.destroy', $thread)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>

            <button>Delete</button>
            
        </form>
    </td>
</tr><?php /**PATH F:\XamPP\htdocs\bai1.2\resources\views/messenger/partials/thread.blade.php ENDPATH**/ ?>