<!DOCTYPE html>
<html>
    <head>
    <title>Challenge details</title>
    </head>

<body>
    <?php echo e($challenge->name); ?> <br>

    
    <iframe height="650" width="1400" src="http://localhost/bai1.2/storage/app/<?php echo e($challenge->path); ?>"> </iframe>
</body>

</html>

<form action="<?php echo e(route('challenges')); ?> ", method="GET">
    <?php echo csrf_field(); ?>
    <button>
        Back to Challenge
    </button>
</form>

<?php /**PATH F:\XamPP\htdocs\bai1.2\resources\views/file-correctAnswer.blade.php ENDPATH**/ ?>