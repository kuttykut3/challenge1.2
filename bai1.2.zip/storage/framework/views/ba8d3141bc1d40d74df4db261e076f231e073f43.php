<!DOCTYPE html>
<html>
    <head>
    <title>File details</title>
    </head>

<body>
    <?php echo e($viewFile->name); ?> <br>

    <iframe height="650" width="1400" src="http://localhost/bai1.2/storage/app/<?php echo e($viewFile->path); ?>"> </iframe>
</body>

</html>

<form action="<?php echo e(route('assignmentStu')); ?> ", method="GET">
    <?php echo csrf_field(); ?>
    <button>
        Back to Assignments
    </button>
</form>

<?php /**PATH F:\XamPP\htdocs\bai1.2\resources\views/student/viewFile.blade.php ENDPATH**/ ?>