<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1>    <?php echo e($detailuser->name); ?>

    </h1>
    <h3>    <?php echo e(($detailuser->role == '0') ? 'Student' : 'Teacher'); ?>

    </h3>
    <h1>    <?php echo e($detailuser->email); ?>

    </h1>
    <h1>    <?php echo e($detailuser->phone); ?>

    </h1>

    <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">

                    <form action="<?php echo e(route('messages.store')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="col-md-6">
                            <!-- Subject Form Input -->
                            <div>
                                Message Subject:
                                <label for="subject" :value="__('Subject')" >
                                <input id="subject" class="block w-full mt-1" type="text" name="subject"
                                    :value="old('subject')" >
                                    
                            </div>

                            <!-- Recipients list -->
                            <div class="mt-4">
                                <label for="recipient" :value="__('Recipient')" >
                                
                                <select name="recipient"
                                    class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                                        <option value="<?php echo e($detailuser->id); ?>"><?php echo e($detailuser->name); ?></option>
                                </select>
                            </div>

                            <!-- Message Form Input -->
                            <div class="mt-4">
                                Message:
                                <label for="message" :value="__('Message')" >
                                <textarea name="message" rows="10"
                                    class="block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"><?php echo e(old('message')); ?></textarea>
                            </div>

                            <!-- Submit Form Input -->
                            <div class="mt-4">
                                <button>Send</button>
                                
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <div>
        <form action="<?php echo e(route('messages')); ?> ", method="GET">
            <?php echo csrf_field(); ?>
                <button>
                    View Messages Sent
                </button>
        </form>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

   

<?php /**PATH F:\XamPP\htdocs\bai1.2\resources\views/users/detail.blade.php ENDPATH**/ ?>