

    <form action="<?php echo e(route('redirect')); ?> ", method="GET">
        <?php echo csrf_field(); ?>
        <button>
            Back to Home
        </button>
    </form>

    <form action="<?php echo e(route('listUserStu')); ?> ", method="GET">
        <?php echo csrf_field(); ?>
        <button>
            Users
        </button>
    </form>

    <form action="<?php echo e(route('messages')); ?> ", method="GET">
        <?php echo csrf_field(); ?>
            <button>
                Messages
            </button>
    </form>

    <form action="<?php echo e(route('assignmentStu')); ?> ", method="GET">
        <?php echo csrf_field(); ?>
        <button>
            Assignment
        </button>
        </form>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('List Challenges')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

   <table border="1" width="100%">
       <tr>
           <th>Challenge Name</th>
           <th>#</th>
       </tr>
       <?php $__currentLoopData = $challenges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $challenge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
               <td><?php echo e($challenge->challengeName); ?></td>
               <td> 
                   <form action="<?php echo e(route('detailChallengeStu', ['id' => $challenge->id])); ?> ", method="GET">
                       <?php echo csrf_field(); ?>
                       <button>
                           Detail
                       </button>
                   </form>
   
               </td>
               
           </tr>    
           
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </table>
   <?php echo e($challenges->links()); ?>


   <?php /**PATH F:\XamPP\htdocs\bai1.2\resources\views/student/challenges.blade.php ENDPATH**/ ?>