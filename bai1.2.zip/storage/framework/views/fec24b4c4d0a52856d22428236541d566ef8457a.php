<!DOCTYPE html>
<html>
<head>
  <title>Upload File</title>
 
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
 
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
 
 
</head>
<body>
 
<div class="container mt-4">
 
  <h2 class="text-center">Change File</h2>
 
      <form method="POST" enctype="multipart/form-data" id="upload-file" action="<?php echo e(route('updateFile', $changeFile)); ?>" >
       <?php echo csrf_field(); ?>  
       <?php echo method_field('PUT'); ?>        
          <div class="row">
 
              <div class="col-md-12">
                  <div class="form-group">
                      <input type="file" name="file" placeholder="Choose file" id="file">
                        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
              </div>
                 
              <div class="col-md-12">
                  <button type="submit" class="btn btn-primary" id="submit">Submit</button>
              </div>
          </div>     
      </form>
</div>
 
</div>  
</body>
</html><?php /**PATH F:\XamPP\htdocs\bai1.2\resources\views/file-change.blade.php ENDPATH**/ ?>